package com.spring.hibernate;

public interface UserDaoInterface {
	public boolean add(int num);

	public boolean read(int num);

	public boolean update(int num);

	public boolean delete(int num);
}
