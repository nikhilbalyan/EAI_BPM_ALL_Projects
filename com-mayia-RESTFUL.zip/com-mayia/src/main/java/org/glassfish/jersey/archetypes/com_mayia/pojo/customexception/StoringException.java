package org.glassfish.jersey.archetypes.com_mayia.pojo.customexception;

public class StoringException extends Exception {
	public StoringException(String message) {
		super(message);
	}
}
